﻿using System;

namespace FinalTuermeVonHanoi;

class Program
{
    public static int RequestDiskAmount()
    {
        int amountOfDisks = 0;
        int diskLimiter = 8;
        bool validAmountOfDisks = false;
        bool notAnInt = true;

        do
        {
            Console.WriteLine($"Please enter the number of disks to be used (between 1 and {diskLimiter}): ");

            string input = "";
            while (notAnInt)
            {
                input = Console.ReadLine();
                try
                {
                    bool successfullyParsed = int.TryParse(input, out amountOfDisks);

                    notAnInt = false;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                }
            }

            if (amountOfDisks >= 1 && amountOfDisks <= diskLimiter)
                validAmountOfDisks = true;
            else if (amountOfDisks < 1)
            {
                Console.WriteLine("You entered too few disks, it must be over 1");

            }
            else
            {
                Console.WriteLine($"You entered too many disks, it must be under {diskLimiter + 1}");
            }
        } while (!validAmountOfDisks);

        return amountOfDisks;
    }

    public static List<int>[] InitializeGame(int amountOfDisks)
    {
        List<int>[] towerArray = new List<int>[3];

        for (int i = 0; i < towerArray.Length; i++)
        {
            towerArray[i] = new List<int>();
        }

        int j = amountOfDisks;
        for (int i = 0; i < amountOfDisks; i++, j--)
        {
            towerArray[0].Add(j);
        }

        return towerArray;
    }



    public static int RequestGametype()
    {
        int gameType = 0;

        Console.WriteLine("Choose your game type: Auto(1), Manual(2)");
        string input = "";
        bool notAnInt = true;
        bool validGameType = true;

        // forcing valid integer input from user
        while (notAnInt || validGameType)
        {
            input = Console.ReadLine();
            try
            {
                // gameType = Convert.ToInt32(input);
                bool successfullyParsed = int.TryParse(input, out gameType);
                if (gameType >= 1 && gameType <= 2)
                {
                    validGameType = false;
                }
                notAnInt = false;
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please enter an integer.");
                continue;
            }
            if (validGameType)
            {
                Console.WriteLine("Invalid input. Please enter a valid integer (1 or 2).");
            }
        }
        return gameType;
    }


    static void AutoSolve(int amountOfDisks, char x, char y, char z)

    {
        if (amountOfDisks == 1)
        {
            Console.WriteLine($"Moving disk 1 from {x} to {z}");
            return;
        }

        AutoSolve(amountOfDisks - 1, x, z, y);
        Console.WriteLine($"Moving disk {amountOfDisks} from {x} to {z}");

        AutoSolve(amountOfDisks - 1, y, x, z);

    }

    // ManualSolve()
    // RequestStartTower()
    // ValidateInput()
    // RequestTargetTower()
    // ValidateInput()
    // CheckIfMovable()
    // MoveDisks()
    // CheckWinningCondition()



    public static void Main()
    {
        int amountOfDisks;
        amountOfDisks = RequestDiskAmount();
        Console.WriteLine($"AMOUNT OF DISKS ENTERED: {amountOfDisks}");

        List<int>[] towerArray = new List<int>[3];
        towerArray = InitializeGame(amountOfDisks);
        Console.WriteLine($"FIRST TOWER SIZE: {towerArray[0].Count}");

        int gameType;
        gameType = RequestGametype();
        Console.WriteLine($"GAMETYPE CHOSEN: {gameType}");


        if (gameType == 1)
        {
            AutoSolve(amountOfDisks, 'A', 'B', 'C');
        }

        // ManualSolve()
    }
}

